import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';

export default class Box extends React.Component {

  changeSource = (char) => {

    this.source = char;

  }


  render(){

    const X = require('./X.png');
    const O = require('./O.png');

    var source = '';




    return (
        <View style={styles.box}>
          <TouchableOpacity style={{flex: 1}} onPress={this.props.onPress}>
            <Image style={{height: 30, width: 30, justifyContent: 'center'}} source={X} />
          </TouchableOpacity>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  box: {
    width: 75,
    height: 75,
    backgroundColor: 'white',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'black',
  },
  boxText: {
    flex: 1,
    fontSize: 40,
    lineHeight: 85,
    fontWeight: 'bold',
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});
