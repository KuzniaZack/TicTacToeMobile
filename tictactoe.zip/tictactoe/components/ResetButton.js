import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, Text, View, ImageBackground, TouchableOpacity } from 'react-native';

export default class resetButton extends React.Component {

  render(){
    return (
        <View style={styles.resetButton}>
          <TouchableOpacity style={{flex: 1}} onPress={this.props.onPress}>
            <Text style={styles.resetButtonText}>{this.props.placeholder}</Text>
          </TouchableOpacity>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  resetButton: {
    width: 150,
    height: 70,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'black'
  },
  resetButtonText: {
    flex: 1,
    fontSize: 20,
    lineHeight: 85,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});
