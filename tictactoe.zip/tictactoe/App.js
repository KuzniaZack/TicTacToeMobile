import React from 'react';
import { StyleSheet, Text, View, ImageBackground, TouchableOpacity, Image } from 'react-native';

import Box from './components/box';
import ResetButton from './components/ResetButton';

export default class App extends React.Component {

  state = {
    board: ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
    currentPlayer: 'X',
    winner: '?',
    clicks: 0,
  };

  changeBoxImage = (char) => {
    this.refs.child.changeSource(char);
  }

  handlePress = (index) => {

      if(this.state.board[index] === 'X' || this.state.board[index] === 'O' || this.state.winner != '?')
        return;

      let currentPlayerCopy = this.state.currentPlayer;
      let boardCopy = [...this.state.board];
      let clicksCopy = this.state.clicks;
      boardCopy[index] = currentPlayerCopy;
      this.changeBoxImage(this.state.currentPlayer);
      if(this.state.currentPlayer === 'X') this.setState({currentPlayer: 'O'});
      if(this.state.currentPlayer === 'O') this.setState({currentPlayer: 'X'});
      this.setState({board: boardCopy});

      const { board } = this.state;

      //rows for x
      if(boardCopy[0] === 'X' && boardCopy[1] === 'X' && boardCopy[2] === 'X') this.setState({winner: 'X'});
      if(boardCopy[3] === 'X' && boardCopy[4] === 'X' && boardCopy[5] === 'X') this.setState({winner: 'X'});
      if(boardCopy[6] === 'X' && boardCopy[7] === 'X' && boardCopy[8] === 'X') this.setState({winner: 'X'});

      //rows for O
      if(boardCopy[0] === 'O' && boardCopy[1] === 'O' && boardCopy[2] === 'O') this.setState({winner: 'O'});
      if(boardCopy[3] === 'O' && boardCopy[4] === 'O' && boardCopy[5] === 'O') this.setState({winner: 'O'});
      if(boardCopy[6] === 'O' && boardCopy[7] === 'O' && boardCopy[8] === 'O') this.setState({winner: 'O'});

      //colums for x
      if(boardCopy[0] === 'X' && boardCopy[3] === 'X' && boardCopy[6] === 'X') this.setState({winner: 'X'});
      if(boardCopy[1] === 'X' && boardCopy[4] === 'X' && boardCopy[7] === 'X') this.setState({winner: 'X'});
      if(boardCopy[2] === 'X' && boardCopy[5] === 'X' && boardCopy[8] === 'X') this.setState({winner: 'X'});

      //colums for O
      if(boardCopy[0] === 'O' && boardCopy[3] === 'O' && boardCopy[6] === 'O') this.setState({winner: 'O'});
      if(boardCopy[1] === 'O' && boardCopy[4] === 'O' && boardCopy[7] === 'O') this.setState({winner: 'O'});
      if(boardCopy[2] === 'O' && boardCopy[5] === 'O' && boardCopy[8] === 'O') this.setState({winner: 'O'});

      //diagonals for x
      if(boardCopy[0] === 'X' && boardCopy[4] === 'X' && boardCopy[8] === 'X') this.setState({winner: 'X'});
      if(boardCopy[2] === 'X' && boardCopy[4] === 'X' && boardCopy[6] === 'X') this.setState({winner: 'X'});

      //diagonals for O
      if(boardCopy[0] === 'O' && boardCopy[4] === 'O' && boardCopy[8] === 'O') this.setState({winner: 'O'});
      if(boardCopy[2] === 'O' && boardCopy[4] === 'O' && boardCopy[6] === 'O') this.setState({winner: 'O'});

      this.setState({clicks: clicksCopy + 1});
  }

  handleReset = () => {
    this.setState({board: ['1', '2', '3', '4', '5', '6', '7', '8', '9']});
    this.setState({winner: '?'});
    this.setState({currentPlayer: 'X'});
    this.setState({clicks: 0});
  }



  render(){
    return (
      <ImageBackground style={styles.bg} source={require('./assets/backgroundImage.jpg')}>
      <View style={styles.container}>

      <View style={styles.rowContainer}>
        <Box  ref = 'child' placeholder={this.state.board[0]} onPress={()=>this.handlePress(0)}/>
        <Box placeholder={this.state.board[1]} onPress={()=>this.handlePress(1)}/>
        <Box placeholder={this.state.board[2]} onPress={()=>this.handlePress(2)}/>
      </View>

      <View style={styles.rowContainer}>
        <Box placeholder={this.state.board[3]} onPress={()=>this.handlePress(3)}/>
        <Box placeholder={this.state.board[4]} onPress={()=>this.handlePress(4)}/>
        <Box placeholder={this.state.board[5]} onPress={()=>this.handlePress(5)}/>
      </View>

      <View style={styles.rowContainer}>
        <Box placeholder={this.state.board[6]} onPress={()=>this.handlePress(6)}/>
        <Box placeholder={this.state.board[7]} onPress={()=>this.handlePress(7)}/>
        <Box placeholder={this.state.board[8]} onPress={()=>this.handlePress(8)}/>
      </View>

        <Text style={styles.title}>ticTacToe</Text>
        {
          this.state.winner !== '?' &&
          <Text style={styles.title}>{this.state.winner} wins!</Text>
        }

        {
          (this.state.winner !== '?' || this.state.clicks === 9) &&
          <ResetButton placeholder='Restart game' onPress={()=>this.handleReset()}/>
        }

      </View>
      </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resetButton: {
    width: 75,
    height: 75,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: 'black'
  },
  boxText: {
    flex: 1,
    fontSize: 40,
    lineHeight: 85,
    fontWeight: 'bold',
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  rowContainer: {
    flexDirection: 'row',
  },
  title: {
    fontSize: 40,
  },
  bg: {
    flex: 1,
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
});
